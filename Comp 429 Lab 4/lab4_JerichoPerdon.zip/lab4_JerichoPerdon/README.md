
Jericho Perdon
Prof Scrivnor 
Comp 429
1 March 2021

Lab 4

How to run:

(How I did the lab)

Place the harhar folder and the har.py file on Desktop

Note: Was not able to figure out how to display the data correctly in task 3